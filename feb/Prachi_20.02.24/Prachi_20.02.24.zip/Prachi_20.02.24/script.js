message="Good evening"
function hello1(){
    let message="Good morning"
    {
        let message="Good afternoon"
        console.log("Hello 1:" + message)
    }
}
hello1() 